import{s as e,p as r}from"./CZjifAYM.js";const t={get error(){return r.error},get params(){return r.params},get status(){return r.status}};e.updated.check;const a=t;export{a as p};
